print("Welcome to the Band name generator.")
a=input("Whats the name of the city you grew up in? \n")
b=input("Whats your pets name?")
print("Your band name could be: "+ a + " " + b)